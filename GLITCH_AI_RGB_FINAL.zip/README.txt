GLITCH AI RGB FINAL
Set GEMINI_API_KEY on the server. Do not put the key in index.html.
Windows CMD: set GEMINI_API_KEY=YOUR_KEY
Then: node server.js
Open: http://localhost:3000
For public use, deploy server.js on a Node-compatible host and add GEMINI_API_KEY as a secret/environment variable.
